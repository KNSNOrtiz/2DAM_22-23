﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class winMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.EjerciciosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.mitEj1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mitEj2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mitEj3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mitEj4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mitEj5 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mitEj6 = New System.Windows.Forms.ToolStripMenuItem()
        Me.Ejercicio7NOIMPLEMENTToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.mitEj8 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mitEj9 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mitEj10 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mitLimpiar = New System.Windows.Forms.ToolStripMenuItem()
        Me.lblCircunferencia = New System.Windows.Forms.Label()
        Me.lblArea = New System.Windows.Forms.Label()
        Me.lblDiametro = New System.Windows.Forms.Label()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.EjerciciosToolStripMenuItem, Me.mitLimpiar})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(784, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'EjerciciosToolStripMenuItem
        '
        Me.EjerciciosToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mitEj1, Me.mitEj2, Me.mitEj3, Me.mitEj4, Me.mitEj5, Me.mitEj6, Me.Ejercicio7NOIMPLEMENTToolStripMenuItem, Me.mitEj8, Me.mitEj9, Me.mitEj10})
        Me.EjerciciosToolStripMenuItem.Name = "EjerciciosToolStripMenuItem"
        Me.EjerciciosToolStripMenuItem.Size = New System.Drawing.Size(68, 20)
        Me.EjerciciosToolStripMenuItem.Text = "Ejercicios"
        '
        'mitEj1
        '
        Me.mitEj1.Name = "mitEj1"
        Me.mitEj1.Size = New System.Drawing.Size(224, 22)
        Me.mitEj1.Text = "Ejercicio 1"
        '
        'mitEj2
        '
        Me.mitEj2.Name = "mitEj2"
        Me.mitEj2.Size = New System.Drawing.Size(224, 22)
        Me.mitEj2.Text = "Ejercicio 2"
        '
        'mitEj3
        '
        Me.mitEj3.Name = "mitEj3"
        Me.mitEj3.Size = New System.Drawing.Size(224, 22)
        Me.mitEj3.Text = "Ejercicio 3"
        '
        'mitEj4
        '
        Me.mitEj4.Name = "mitEj4"
        Me.mitEj4.Size = New System.Drawing.Size(224, 22)
        Me.mitEj4.Text = "Ejercicio 4"
        '
        'mitEj5
        '
        Me.mitEj5.Name = "mitEj5"
        Me.mitEj5.Size = New System.Drawing.Size(224, 22)
        Me.mitEj5.Text = "Ejercicio 5"
        '
        'mitEj6
        '
        Me.mitEj6.Name = "mitEj6"
        Me.mitEj6.Size = New System.Drawing.Size(224, 22)
        Me.mitEj6.Text = "Ejercicio 6"
        '
        'Ejercicio7NOIMPLEMENTToolStripMenuItem
        '
        Me.Ejercicio7NOIMPLEMENTToolStripMenuItem.Name = "Ejercicio7NOIMPLEMENTToolStripMenuItem"
        Me.Ejercicio7NOIMPLEMENTToolStripMenuItem.Size = New System.Drawing.Size(224, 22)
        Me.Ejercicio7NOIMPLEMENTToolStripMenuItem.Text = "Ejercicio 7 (NO IMPLEMENT)"
        '
        'mitEj8
        '
        Me.mitEj8.Name = "mitEj8"
        Me.mitEj8.Size = New System.Drawing.Size(224, 22)
        Me.mitEj8.Text = "Ejercicio 8"
        '
        'mitEj9
        '
        Me.mitEj9.Name = "mitEj9"
        Me.mitEj9.Size = New System.Drawing.Size(224, 22)
        Me.mitEj9.Text = "Ejercicio 9"
        '
        'mitEj10
        '
        Me.mitEj10.Name = "mitEj10"
        Me.mitEj10.Size = New System.Drawing.Size(224, 22)
        Me.mitEj10.Text = "Ejercicio 10"
        '
        'mitLimpiar
        '
        Me.mitLimpiar.Name = "mitLimpiar"
        Me.mitLimpiar.Size = New System.Drawing.Size(93, 20)
        Me.mitLimpiar.Text = "Limpiar lienzo"
        '
        'lblCircunferencia
        '
        Me.lblCircunferencia.AutoSize = True
        Me.lblCircunferencia.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lblCircunferencia.Location = New System.Drawing.Point(542, 47)
        Me.lblCircunferencia.Name = "lblCircunferencia"
        Me.lblCircunferencia.Size = New System.Drawing.Size(91, 15)
        Me.lblCircunferencia.TabIndex = 2
        Me.lblCircunferencia.Text = "Circunferencia:"
        Me.lblCircunferencia.Visible = False
        '
        'lblArea
        '
        Me.lblArea.AutoSize = True
        Me.lblArea.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lblArea.Location = New System.Drawing.Point(320, 47)
        Me.lblArea.Name = "lblArea"
        Me.lblArea.Size = New System.Drawing.Size(36, 15)
        Me.lblArea.TabIndex = 1
        Me.lblArea.Text = "Área:"
        Me.lblArea.Visible = False
        '
        'lblDiametro
        '
        Me.lblDiametro.AutoSize = True
        Me.lblDiametro.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lblDiametro.Location = New System.Drawing.Point(96, 47)
        Me.lblDiametro.Name = "lblDiametro"
        Me.lblDiametro.Size = New System.Drawing.Size(63, 15)
        Me.lblDiametro.TabIndex = 0
        Me.lblDiametro.Text = "Diámetro:"
        Me.lblDiametro.Visible = False
        '
        'winMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(784, 461)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.lblDiametro)
        Me.Controls.Add(Me.lblCircunferencia)
        Me.Controls.Add(Me.lblArea)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(1920, 1080)
        Me.MinimumSize = New System.Drawing.Size(800, 500)
        Me.Name = "winMain"
        Me.Text = "Ejercicios sobre Graphics | Ortiz Jibaja, Mario"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents EjerciciosToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents mitEj1 As ToolStripMenuItem
    Friend WithEvents mitEj2 As ToolStripMenuItem
    Friend WithEvents mitLimpiar As ToolStripMenuItem
    Friend WithEvents mitEj3 As ToolStripMenuItem
    Friend WithEvents mitEj4 As ToolStripMenuItem
    Friend WithEvents mitEj5 As ToolStripMenuItem
    Friend WithEvents mitEj6 As ToolStripMenuItem
    Friend WithEvents Ejercicio7NOIMPLEMENTToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents mitEj8 As ToolStripMenuItem
    Friend WithEvents mitEj9 As ToolStripMenuItem
    Friend WithEvents mitEj10 As ToolStripMenuItem
    Friend WithEvents lblDiametro As Label
    Friend WithEvents lblCircunferencia As Label
    Friend WithEvents lblArea As Label
End Class

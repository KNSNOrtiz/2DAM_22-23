﻿Public Class moj_formInfo
    Private Sub moj_btnSalir_Click(sender As Object, e As EventArgs) Handles moj_btnSalir.Click
        Me.Close()
    End Sub

End Class
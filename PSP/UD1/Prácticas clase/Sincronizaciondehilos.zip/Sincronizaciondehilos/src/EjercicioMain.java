public class EjercicioMain {
    public static RecursoCompartido libro = new RecursoCompartido();
    
    public static void main(String[] args) {
        Lector lector1 = new Lector(libro, "Lector 1");
        Lector lector2 = new Lector(libro, "Lector 2");
        Escritor escritor1 = new Escritor(libro, "Escritor 1");
        escritor1.setPriority(1);
        lector1.setPriority(10);
        lector2.setPriority(10);
        escritor1.start();
        lector1.start();
        lector2.start();
    }
    
}